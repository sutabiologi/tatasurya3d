
import * as THREE from "three";
import { OrbitControls } from "three/addons/controls/OrbitControls.js";

// ============================================
// 1. SCENE DAN KAMERA
// ============================================

const scene = new THREE.Scene();

scene.background = new THREE.Color(0x000008);
scene.fog = new THREE.FogExp2(0x000008, 0.00012);

const camera = new THREE.PerspectiveCamera(
  50,
  window.innerWidth / window.innerHeight,
  0.1,
  5000
);

camera.position.set(0, 180, 360);

const renderer = new THREE.WebGLRenderer({
  antialias: true
});

renderer.setSize(window.innerWidth, window.innerHeight);
renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
renderer.outputColorSpace = THREE.SRGBColorSpace;
renderer.toneMapping = THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure = 1.2;

document.body.appendChild(renderer.domElement);

// ============================================
// 2. KONTROL KAMERA
// ============================================

const controls = new OrbitControls(
  camera,
  renderer.domElement
);

controls.enableDamping = true;
controls.dampingFactor = 0.04;
controls.minDistance = 12;
controls.maxDistance = 700;
controls.maxPolarAngle = Math.PI * 0.85;

// ============================================
// 3. PENCAHAYAAN
// ============================================

scene.add(
  new THREE.AmbientLight(0xffffff, 0.08)
);

const sunLight = new THREE.PointLight(
  0xffffff,
  3000,
  1200,
  1.2
);

sunLight.position.set(0, 0, 0);
scene.add(sunLight);

// ============================================
// 4. BINTANG RUANG ANGKASA
// ============================================

const starGeometry = new THREE.BufferGeometry();
const starPositions = [];

for (let i = 0; i < 12000; i++) {

  const radius = 500 + Math.random() * 1500;

  const theta = Math.random() * Math.PI * 2;
  const phi = Math.acos(2 * Math.random() - 1);

  starPositions.push(
    radius * Math.sin(phi) * Math.cos(theta),
    radius * Math.cos(phi),
    radius * Math.sin(phi) * Math.sin(theta)
  );
}

starGeometry.setAttribute(
  "position",
  new THREE.Float32BufferAttribute(starPositions, 3)
);

const starMaterial = new THREE.PointsMaterial({
  color: 0xffffff,
  size: 1.2,
  sizeAttenuation: true
});

const stars = new THREE.Points(
  starGeometry,
  starMaterial
);

scene.add(stars);

// ============================================
// 5. MEMBUAT TEKSTUR PLANET
// ============================================

function createPlanetTexture(
  baseColor,
  variationColor,
  seed = 1
) {

  const canvas = document.createElement("canvas");

  canvas.width = 1024;
  canvas.height = 512;

  const ctx = canvas.getContext("2d");

  ctx.fillStyle = baseColor;
  ctx.fillRect(0, 0, 1024, 512);

  let state = seed;

  function random() {

    state = (state * 16807) % 2147483647;

    return (state - 1) / 2147483646;
  }

  for (let i = 0; i < 1200; i++) {

    const x = random() * 1024;
    const y = random() * 512;

    const width = 10 + random() * 100;
    const height = 2 + random() * 18;

    ctx.fillStyle = variationColor;
    ctx.globalAlpha = 0.08 + random() * 0.2;

    ctx.beginPath();

    ctx.ellipse(
      x,
      y,
      width,
      height,
      random() * 0.2,
      0,
      Math.PI * 2
    );

    ctx.fill();
  }

  ctx.globalAlpha = 1;

  const texture = new THREE.CanvasTexture(canvas);

  texture.colorSpace = THREE.SRGBColorSpace;

  return texture;
}

// ============================================
// 6. MEMBUAT MATAHARI
// ============================================

const sunGeometry = new THREE.SphereGeometry(
  10,
  96,
  96
);

const sunMaterial = new THREE.MeshBasicMaterial({
  color: 0xffa52b
});

const sun = new THREE.Mesh(
  sunGeometry,
  sunMaterial
);

scene.add(sun);

// ============================================
// 7. EFEK GLOW MATAHARI
// ============================================

function createGlowTexture() {

  const canvas = document.createElement("canvas");

  canvas.width = 256;
  canvas.height = 256;

  const ctx = canvas.getContext("2d");

  const gradient = ctx.createRadialGradient(
    128, 128, 5,
    128, 128, 128
  );

  gradient.addColorStop(
    0,
    "rgba(255,240,160,1)"
  );

  gradient.addColorStop(
    0.2,
    "rgba(255,160,40,0.65)"
  );

  gradient.addColorStop(
    0.5,
    "rgba(255,90,10,0.2)"
  );

  gradient.addColorStop(
    1,
    "rgba(255,50,0,0)"
  );

  ctx.fillStyle = gradient;
  ctx.fillRect(0, 0, 256, 256);

  return new THREE.CanvasTexture(canvas);
}

const glow = new THREE.Sprite(
  new THREE.SpriteMaterial({
    map: createGlowTexture(),
    blending: THREE.AdditiveBlending,
    transparent: true,
    depthWrite: false
  })
);

glow.scale.set(45, 45, 1);

scene.add(glow);

// ============================================
// 8. DATA DELAPAN PLANET
// ============================================

const planetData = [

  {
    name: "Merkurius",
    radius: 0.38,
    distance: 25,
    color: "#777777",
    variation: "#b4aaa0",
    rotation: 0.5,
    speed: 3.0,
    seed: 1,
    info: "Planet terkecil dan terdekat dengan Matahari."
  },

  {
    name: "Venus",
    radius: 0.95,
    distance: 38,
    color: "#bd8850",
    variation: "#f0d19a",
    rotation: -0.2,
    speed: 1.6,
    seed: 2,
    info: "Planet dengan atmosfer tebal dan suhu sangat panas."
  },

  {
    name: "Bumi",
    radius: 1,
    distance: 52,
    color: "#123c87",
    variation: "#38a66a",
    rotation: 1,
    speed: 1,
    seed: 3,
    info: "Planet tempat kehidupan manusia dan memiliki air cair."
  },

  {
    name: "Mars",
    radius: 0.53,
    distance: 79,
    color: "#9d3925",
    variation: "#d98b5c",
    rotation: 0.9,
    speed: 0.67,
    seed: 4,
    info: "Planet merah dengan permukaan berbatu."
  },

  {
    name: "Jupiter",
    radius: 5.5,
    distance: 135,
    color: "#b28a68",
    variation: "#f2d3ae",
    rotation: 2,
    speed: 0.24,
    seed: 5,
    info: "Planet terbesar dengan badai raksasa."
  },

  {
    name: "Saturnus",
    radius: 4.6,
    distance: 190,
    color: "#c5aa7b",
    variation: "#f2dfb5",
    rotation: 1.8,
    speed: 0.14,
    seed: 6,
    info: "Planet dengan sistem cincin yang sangat indah."
  },

  {
    name: "Uranus",
    radius: 2,
    distance: 250,
    color: "#69b9c9",
    variation: "#b0e8e8",
    rotation: 1.2,
    speed: 0.095,
    seed: 7,
    info: "Planet es raksasa dengan sumbu rotasi sangat miring."
  },

  {
    name: "Neptunus",
    radius: 1.95,
    distance: 310,
    color: "#173dba",
    variation: "#658eff",
    rotation: 1.3,
    speed: 0.069,
    seed: 8,
    info: "Planet terjauh dari Matahari."
  }

];

// ============================================
// 9. MEMBUAT ORBIT PLANET
// ============================================

function createOrbit(distance) {

  const points = [];

  for (let i = 0; i <= 256; i++) {

    const angle = (i / 256) * Math.PI * 2;

    points.push(
      new THREE.Vector3(
        Math.cos(angle) * distance,
        0,
        Math.sin(angle) * distance
      )
    );
  }

  const geometry = new THREE.BufferGeometry()
    .setFromPoints(points);

  const material = new THREE.LineBasicMaterial({
    color: 0x52617d,
    transparent: true,
    opacity: 0.35
  });

  const orbit = new THREE.LineLoop(
    geometry,
    material
  );

  scene.add(orbit);
}

// ============================================
// 10. MEMBUAT SEMUA PLANET
// ============================================

const planets = [];

planetData.forEach((data) => {

  createOrbit(data.distance);

  // Pusat revolusi

  const pivot = new THREE.Group();

  scene.add(pivot);

  // Bentuk planet

  const geometry = new THREE.SphereGeometry(
    data.radius,
    96,
    96
  );

  // Tekstur planet

  const texture = createPlanetTexture(
    data.color,
    data.variation,
    data.seed
  );

  const material = new THREE.MeshStandardMaterial({
    map: texture,
    roughness: 0.9,
    metalness: 0
  });

  const mesh = new THREE.Mesh(
    geometry,
    material
  );

  mesh.position.x = data.distance;

  pivot.add(mesh);

  // Kemiringan sumbu Uranus

  if (data.name === "Uranus") {
    mesh.rotation.z = Math.PI / 2;
  }

  // CINCIN SATURNUS

  if (data.name === "Saturnus") {

    const ringGeometry = new THREE.RingGeometry(
      data.radius * 1.25,
      data.radius * 2.3,
      160
    );

    const ringMaterial = new THREE.MeshStandardMaterial({
      color: 0xcbb68d,
      side: THREE.DoubleSide,
      transparent: true,
      opacity: 0.9,
      roughness: 1
    });

    const ring = new THREE.Mesh(
      ringGeometry,
      ringMaterial
    );

    ring.rotation.x = Math.PI / 2.4;

    mesh.add(ring);
  }

  // ATMOSFER BUMI

  if (data.name === "Bumi") {

    const atmosphere = new THREE.Mesh(
      new THREE.SphereGeometry(
        data.radius * 1.08,
        64,
        64
      ),

      new THREE.MeshBasicMaterial({
        color: 0x3388ff,
        transparent: true,
        opacity: 0.09,
        side: THREE.BackSide
      })
    );

    mesh.add(atmosphere);
  }

  planets.push({
    ...data,
    pivot,
    mesh,
    angle: Math.random() * Math.PI * 2
  });

});

// ============================================
// 11. MEMBUAT BULAN
// ============================================

const earth = planets.find(
  planet => planet.name === "Bumi"
);

const moonPivot = new THREE.Group();

earth.mesh.add(moonPivot);

const moonGeometry = new THREE.SphereGeometry(
  0.25,
  48,
  48
);

const moonMaterial = new THREE.MeshStandardMaterial({
  map: createPlanetTexture(
    "#777777",
    "#aaaaaa",
    20
  ),
  roughness: 1
});

const moon = new THREE.Mesh(
  moonGeometry,
  moonMaterial
);

moon.position.x = 2.8;

moonPivot.add(moon);

// ============================================
// 12. INTERAKSI KLIK PLANET
// ============================================

const raycaster = new THREE.Raycaster();

const mouse = new THREE.Vector2();

const infoPanel = document.getElementById("planetInfo");

const clickableObjects = planets.map(
  planet => planet.mesh
);

renderer.domElement.addEventListener(
  "click",
  (event) => {

    mouse.x =
      (event.clientX / window.innerWidth) * 2 - 1;

    mouse.y =
      -(event.clientY / window.innerHeight) * 2 + 1;

    raycaster.setFromCamera(mouse, camera);

    const hits = raycaster.intersectObjects(
      clickableObjects,
      false
    );

    if (hits.length > 0) {

      const selected = planets.find(
        planet => planet.mesh === hits[0].object
      );

      if (selected) {

        infoPanel.innerHTML = `
          <strong>${selected.name}</strong>
          <div>Jarak orbit: ${selected.distance} unit</div>
          <div>Radius planet: ${selected.radius} unit</div>
          <div>${selected.info}</div>
        `;
      }
    }

  }
);

// ============================================
// 13. KONTROL SIMULASI
// ============================================

let paused = false;

let simulationSpeed = 1;

const speedSlider = document.getElementById("speed");

const speedValue = document.getElementById("speedValue");

const pauseBtn = document.getElementById("pauseBtn");

const resetBtn = document.getElementById("resetBtn");

// Kontrol kecepatan

speedSlider.addEventListener("input", () => {

  simulationSpeed = Number(speedSlider.value);

  speedValue.textContent =
    simulationSpeed.toFixed(1) + "x";

});

// Tombol jeda

pauseBtn.addEventListener("click", () => {

  paused = !paused;

  pauseBtn.textContent = paused
    ? "▶ Lanjut"
    : "⏸ Jeda";

});

// Tombol reset

resetBtn.addEventListener("click", () => {

  planets.forEach((planet, index) => {

    planet.angle = index * 0.8;

    planet.mesh.rotation.set(0, 0, 0);

  });

  moonPivot.rotation.set(0, 0, 0);

  sun.rotation.set(0, 0, 0);

  camera.position.set(0, 180, 360);

  controls.target.set(0, 0, 0);

  controls.update();

  simulationSpeed = 1;

  speedSlider.value = "1";

  speedValue.textContent = "1.0x";

  paused = false;

  pauseBtn.textContent = "⏸ Jeda";

  infoPanel.innerHTML = `
    <strong>Tata Surya</strong>
    <div>Klik planet untuk melihat informasinya.</div>
  `;

});

// ============================================
// 14. ANIMASI TATA SURYA
// ============================================

const clock = new THREE.Clock();

function animate() {

  requestAnimationFrame(animate);

  const delta = Math.min(
    clock.getDelta(),
    0.05
  );

  if (!paused) {

    // Rotasi Matahari

    sun.rotation.y += delta * 0.08;

    // Revolusi dan rotasi planet

    planets.forEach((planet) => {

      planet.angle +=
        delta *
        planet.speed *
        simulationSpeed *
        0.08;

      planet.pivot.rotation.y = planet.angle;

      planet.mesh.rotation.y +=
        delta *
        planet.rotation *
        simulationSpeed *
        0.15;

    });

    // Revolusi Bulan

    moonPivot.rotation.y +=
      delta * 0.8 * simulationSpeed;

    // Rotasi bintang

    stars.rotation.y += delta * 0.0005;

  }

  controls.update();

  renderer.render(scene, camera);

}

animate();

// ============================================
// 15. RESPONSIF LAYAR
// ============================================

window.addEventListener("resize", () => {

  camera.aspect =
    window.innerWidth / window.innerHeight;

  camera.updateProjectionMatrix();

  renderer.setSize(
    window.innerWidth,
    window.innerHeight
  );

  renderer.setPixelRatio(
    Math.min(window.devicePixelRatio, 2)
  );

});
